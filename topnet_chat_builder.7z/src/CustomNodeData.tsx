export interface CustomNodeData {
    label: string;
    inputValue: string;
    responseValue: string;
}
