export interface TextProps {
    text: string;
    name: string;

}
