export interface Menu {
    name: string;
    value: string;
    id: number;
}
