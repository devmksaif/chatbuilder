import express from 'express';
import bodyParser from 'body-parser';
import { MongoClient } from 'mongodb';
import cors from 'cors';
import crypto from 'crypto';

// Initialize Express app
const app = express();
app.use(cors());
app.use(bodyParser.json());

// MongoDB URI setup
const mongoUri = "mongodb://0.0.0.0:27017/"; // Replace with your MongoDB URI
const client = new MongoClient(mongoUri)
let db;

client.connect().catch(err => console.error(err));
db = client.db("chatbot");

// Node Collection
const nodesCollection = db.collection("nodes");
// Edge Collection
const edgesCollection = db.collection("edges");
const usersCollection = db.collection("users");
const flowsCollection = db.collection("flows");
const facturesCollection = db.collection("factures")

// Add or update a single Node
app.post('/nodes', async (req, res) => {
    try {
        const nodeData = req.body;
        const nodeId = nodeData.id;
        if (!nodeId) {
            return res.status(400).json({ error: "Node ID is required" });
        }

        // Update if exists, insert if not
        await nodesCollection.updateOne({ id: nodeId }, { $set: nodeData }, { upsert: true });
        return res.status(200).json({ message: "Node added/updated successfully", node_id: nodeId });
    } catch (e) {
        return res.status(400).json({ error: e.message });
    }
});

app.post("/fetch_user", async (req, res) => {
    try {
        const userData = req.body;
        if (!userData.username) {
            return res.status(400).json({ error: "Username is required" });
        } else if (!userData.password) {
            return res.status(400).json({ error: "Password is required" });
        } else {
            const userGet = userData.username;
            const passwordGet = userData.password;

            // Find user in the database
            const user = await usersCollection.findOne({ username: userGet, password: passwordGet });

            if (!user) {
                return res.status(200).json({ error: "not_found" });
            } else {
                // Create a token from the username and password
                const data = userGet + ":" + passwordGet;
                const tokenizedData = crypto.createHash('sha256').update(data).digest('hex'); // Hash the data using SHA-256
                console.log(tokenizedData);
                return res.status(200).json({ success: "found", token: tokenizedData });
            }
        }
    } catch (e) {
        console.error(e);
        return res.status(500).json({ error: "server_error" });
    }
});

app.post("/get_flow", async (req, res) => {
    try {
        const getUsername = req.body;
        if (!getUsername.username) {
            return res.status(400).json({ error: "Username is required" });
        } else {
            const username = getUsername.username;

            // Find user in the database
            const flows = await flowsCollection.findOne({ username: username });

            if (!flows) {
                return res.status(200).json({ error: "not_found" });
            } else {
                flows._id = flows._id.toString();
                return res.status(200).json(flows);
            }
        }
    } catch (e) {
        console.error(e);
        return res.status(500).json({ error: "server_error" });
    }
});

app.post("/get_facture",async(req,res) => {
    try {
        const cin = req.body.cin;
        const nligne = req.body.nligne
        if(cin) {
            const get_facture = await facturesCollection.find({utilisateur : cin , statut : "impayee"}).toArray()
            if(get_facture) {
                const result = get_facture.map(item => {
                    item._id = item._id.toString();
                    return item
                });
                 
                return res.status(200).json(result);
            }else{
                return res.status(200).json({ error: "not_found" });
            }
        }
        if(nligne) {
            const get_facture = await facturesCollection.find({numero_ligne : nligne, statut : "impayee"}).toArray()
            if(get_facture) {
                const result = get_facture.map(item => {
                    item._id = item._id.toString();
                    return item
                });
                 
                return res.status(200).json(result);
            }else{
                return res.status(200).json({ error: "not_found" });
            }
        }
        if(!cin && !nligne) {
            return res.status(400).json({ error: "cin or nligne is required" });
        }
    }catch(e) {
        console.error(e);
        return res.status(500).json({ error: "server_error" });
    }
   
})

app.post("/add_flow", async (req, res) => {
    try {
        const getFlow = req.body;
        if (!getFlow.name) {
            return res.status(400).json({ error: "Name is required" });
        } else if (!getFlow.username) {
            return res.status(400).json({ error: "Username is required" });
        } else {
            const username = getFlow.username;
            const name = getFlow.name;
            const newFlow = { name: name };
            const flowsFind = await flowsCollection.findOne({ username: username, "flows.name": name });

            if (!flowsFind) {
                const flowAdd = await flowsCollection.updateOne(
                    { username: username },
                    { $push: { flows: newFlow } }
                );
                if (flowAdd.modifiedCount > 0) {
                    return res.status(200).json({ success: "updated" });
                } else {
                    return res.status(400).json({ error: "not_updated" });
                }
            } else {
                flowsFind._id = flowsFind._id.toString();
                return res.status(200).json({ error: "exists" });
            }
 }
    } catch (e) {
        console.error(e);
        return res.status(500).json({ error: "server_error" });
    }
});

// Add or update a single Edge
app.post('/edges', async (req, res) => {
    try {
        const edgeData = req.body;
        const edgeId = edgeData.id;
        if (!edgeId) {
            return res.status(400).json({ error: "Edge ID is required" });
        }

        // Update if exists, insert if not
        await edgesCollection.updateOne({ id: edgeId }, { $set: edgeData }, { upsert: true });
        return res.status(200).json({ message: "Edge added/updated successfully", edge_id: edgeId });
    } catch (e) {
        return res.status(400).json({ error: e.message });
    }
});

// Add PUT method for updating a Node
app.put('/nodes/:node_id', async (req, res) => {
    try {
        const nodeId = req.params.node_id;
        const nodeData = req.body;
        if (!nodeData) {
            return res.status(400).json({ error: "No data provided" });
        }

        const result = await nodesCollection.updateOne({ id: nodeId }, { $set: { data: nodeData.data } });
        if (result.matchedCount === 0) {
            return res.status(404).json({ message: "Node not found" });
        }
        return res.status(200).json({ message: `Node with id ${nodeId} updated successfully` });
    } catch (e) {
        return res.status(400).json({ error: e.message });
    }
});

app.put('/nodesPos/:node_id', async (req, res) => {
    try {
        const nodeId = req.params.node_id;
        const nodeData = req.body;
        const position = nodeData.position;
        if (!position) {
            return res.status(400).json({ error: "Position data is required" });
        }

        const result = await nodesCollection.updateOne(
            { id: nodeId },
            { $set: { position: position } }
        );

        if (result.matchedCount === 0) {
            return res.status(404).json({ message: "Node not found" });
        }

        return res.status(200).json({ message: `Node ${nodeId} position updated successfully` });
    } catch (e) {
        return res.status(400).json({ error: e.message });
    }
});

// Add PUT method for updating an Edge
app.put('/edges/:edge_id', async (req, res) => {
    try {
        const edgeId = req.params.edge_id;
        const edgeData = req.body;
        if (!edgeData) {
            return res.status(400).json({ error: "No data provided" });
        }

        const result = await edgesCollection.updateOne({ id: edgeId }, { $set: edgeData });
        if (result.matchedCount === 0) {
            return res.status(404).json({ message: "Edge not found" });
        }
        return res.status(200).json({ message: `Edge with id ${edgeId} updated successfully` });
    } catch (e) {
        return res.status(400).json({ error: e.message });
    }
});

// Get all Nodes
app.get('/nodes', async (req, res) => {
    try {
        const flowName = req.query.flow_name;

        // If flowName is provided, filter by flowName
        const nodes = flowName ? await nodesCollection.find({ flow: flowName }).toArray() : await nodesCollection.find().toArray();

        const result = nodes.map(node => {
            node._id = node._id.toString(); // Convert ObjectId to string
            return node;
        });

        return res.status(200).json(result);
    } catch (e) {
        return res.status(400).json({ error: e.message });
    }
});

// Update all Nodes
app.post('/nodes/update_all', async (req, res) => {
    try {
        const nodesData = req.body; // Get list of nodes
        if (!Array.isArray(nodesData)) {
            return res.status(400).json({ error: "Invalid data format. A list of nodes is required." });
        }

        for (const nodeData of nodesData) {
            const nodeId = nodeData.id;
            if (nodeId) {
                await nodesCollection.updateOne({ id: nodeId }, { $set: nodeData }, { upsert: true });
            }
        }

        return res.status(200).json({ message: "All nodes updated successfully" });
    } catch (e) {
        return res.status(400).json({ error: e.message });
    }
});

// Update all Edges
app .post('/edges/update_all', async (req, res) => {
    try {
        const edgesData = req.body; // Get list of edges
        if (!Array.isArray(edgesData)) {
            return res.status(400).json({ error: "Invalid data format. A list of edges is required." });
        }

        for (const edgeData of edgesData) {
            const edgeId = edgeData.id;
            if (edgeId) {
                await edgesCollection.updateOne({ id: edgeId }, { $set: edgeData }, { upsert: true });
            }
        }

        return res.status(200).json({ message: "All edges updated successfully" });
    } catch (e) {
        return res.status(400).json({ error: e.message });
    }
});

// Delete a Node by ID
app.delete('/nodes/:node_id', async (req, res) => {
    try {
        const nodeId = req.params.node_id;
        const result = await nodesCollection.deleteOne({ id: nodeId });
        if (result.deletedCount === 0) {
            return res.status(404).json({ message: "Node not found" });
        }
        return res.status(200).json({ message: `Node with id ${nodeId} deleted successfully` });
    } catch (e) {
        return res.status(400).json({ error: e.message });
    }
});

// Delete an Edge by ID
app.delete('/edges/:edge_id', async (req, res) => {
    try {
        const edgeId = req.params.edge_id;
        const result = await edgesCollection.deleteOne({ id: edgeId });
        if (result.deletedCount === 0) {
            return res.status(404).json({ message: "Edge not found" });
        }
        return res.status(200).json({ message: `Edge with id ${edgeId} deleted successfully` });
    } catch (e) {
        return res.status(400).json({ error: e.message });
    }
});

// Get all Edges
app.get('/edges', async (req, res) => {
    try {
        const flowName = req.query.flow_name;

        // If flowName is provided, filter by flowName
        const edges = flowName ? await edgesCollection.find({ flow: flowName }).toArray() : await edgesCollection.find().toArray();

        const result = edges.map(edge => {
            edge._id = edge._id.toString(); // Convert ObjectId to string
            return edge;
        });

        return res.status(200).json(result);
    } catch (e) {
        return res.status(400).json({ error: e.message });
    }
});

// Default route
app.get('/', (req, res) => {
    res.send("Graph Database Server is running!");
});

// Start the server
const PORT = 7000;
app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server is running on port ${PORT}`);
});